from __future__ import annotations

def create_wine_table_sql(table: str) -> str:
    return f"""
    CREATE TABLE IF NOT EXISTS {table} (
        fixed_acidity DOUBLE PRECISION,
        volatile_acidity DOUBLE PRECISION,
        citric_acid DOUBLE PRECISION,
        residual_sugar DOUBLE PRECISION,
        chlorides DOUBLE PRECISION,
        free_sulfur_dioxide DOUBLE PRECISION,
        total_sulfur_dioxide DOUBLE PRECISION,
        density DOUBLE PRECISION,
        pH DOUBLE PRECISION,
        sulphates DOUBLE PRECISION,
        alcohol DOUBLE PRECISION,
        quality INTEGER,
        ingestion_date TIMESTAMP
    )
    """

def create_eval_table_sql(table: str) -> str:
    return f"""
    CREATE TABLE IF NOT EXISTS {table} (
        run_id text,
        accuracy double precision,
        precision_weighted double precision,
        recall_weighted double precision,
        execution_date date
    )
    """
