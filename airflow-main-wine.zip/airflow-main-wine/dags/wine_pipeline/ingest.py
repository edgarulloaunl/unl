from __future__ import annotations
import pandas as pd
from sqlalchemy.engine import Engine
from datetime import datetime
from .config import Settings

WINE_DATASET_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"

# Mapeo correcto del dataset UCI -> nombres válidos para ML
RENAME_MAP = {
    "fixed acidity": "fixed_acidity",
    "volatile acidity": "volatile_acidity",
    "citric acid": "citric_acid",
    "residual sugar": "residual_sugar",
    "chlorides": "chlorides",
    "free sulfur dioxide": "free_sulfur_dioxide",
    "total sulfur dioxide": "total_sulfur_dioxide",
    "density": "density",
    "pH": "pH",
    "sulphates": "sulphates",
    "alcohol": "alcohol",
    "quality": "target"  # el modelo usará "target"
}


def load_wine_df(ds: str) -> pd.DataFrame:
    df = pd.read_csv(WINE_DATASET_URL, sep=";")

    # Renombrado crítico
    df = df.rename(columns=RENAME_MAP)

    df["ingestion_date"] = datetime.utcnow()
    return df


def write_wine(settings: Settings, df: pd.DataFrame) -> int:
    from airflow.providers.postgres.hooks.postgres import PostgresHook
    engine = PostgresHook(postgres_conn_id=settings.postgres_conn_id).get_sqlalchemy_engine()

    df.to_sql(settings.wine_table, engine, if_exists="append", index=False)
    return len(df)
